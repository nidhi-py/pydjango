from django.shortcuts import render,redirect
from django.http import HttpResponse
from myapp.models import Category,Expense,User
from myapp.form import CategoryForm,ExpenseForm,UserForm
# Create your views here.

def Homepage(request):
    cl=Category.objects.all()
    cat=request.GET.get('cat')  #this is taken from sidebar.html
    if cat is not None:
        el=Expense.objects.filter(cname=cat)
        return render(request,'home.html',{'cl':cl,'el':el})
    else:
        el=Expense.objects.all()
        return render(request,'home.html',{'cl':cl,'el':el})

def addCategorypage(request):  #this will take you to the form page but don't save the data. the save operation is performed by another method viz mentioned below
    c=CategoryForm()
    return render(request,'addcategory.html',{'form':c})

def addCategory(request):
    c=CategoryForm(request.POST)
    c.save()
    return render(request,'home.html')

def CategoryList(request):
    cl=Category.objects.all()
    return render(request,'categorylist.html',{'cl':cl})

def DeleteCategory(request,cname):
    d=Category.objects.get(cname=cname)
    d.delete()
    return redirect('/CategoryList')

def addExpensepage(request):
    e=ExpenseForm()
    return render(request,'addexpense.html',{'e':e})

def addExpense(request):
    e=ExpenseForm(request.POST)
    e.save()
    return render(request,'home.html')

def ExpenseList(request):
    el=Expense.objects.all()
    return render(request,'expenselist.html',{'el':el})

def DeleteExpense(request,id):
    l=Expense.objects.get(id=id)
    l.delete()
    return redirect('/ExpenseList')

def EditExpense(request):
    ename=request.GET.get('ename')
    t=Expense.objects.get(ename=ename)
    f=ExpenseForm(instance=t)
    return render(request,'updateExpense.html',{'fl':f,'ename':ename})

def UpdateExpense(request):
    ename=request.GET.get('ename')
    t=Expense.objects.get(ename=ename)
    f=ExpenseForm(request.POST,instance=t)
    f.save()
    return redirect('/ExpenseList')

def addUserpage(request):
    u=UserForm()
    return render(request,'adduser.html',{'up':u})

def addUser(request):
    u=UserForm(request.POST)
    u.save()
    return render(request,'home.html')


def loginpage(request):
    return render(request,'login.html')

def login(request):
    em=request.POST.get('email')
    passwd=request.POST.get('password')
    ul=User.objects.get(email=em)
    if em==ul.email and passwd==ul.password:
        request.session['user']=em
        return redirect("/Homepage")
    else:
        return HttpResponse("Template not found")
       
    return render(request,'login.html')

def logout(request):
    ls=list(request.session.keys())
    for i in ls:
        del request.session[i]
    return redirect('/Homepage')