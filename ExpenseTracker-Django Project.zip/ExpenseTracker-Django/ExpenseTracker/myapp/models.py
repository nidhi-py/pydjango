from django.db import models

# Create your models here.

class Category(models.Model):
    cname=models.CharField(primary_key=True,max_length=15)

class Expense(models.Model):
    ename=models.TextField(max_length=20)
    cost=models.IntegerField(max_length=None)
    date=models.DateField(max_length=15)
    description=models.TextField(max_length=30,null=True)
    cname=models.ForeignKey(Category,on_delete=models.CASCADE)

class User(models.Model):
    name=models.CharField(max_length=30)
    contact=models.CharField(max_length=15)
    birthdate=models.DateField(max_length=15)
    country=models.CharField(max_length=15)
    birthdate=models.DateField(max_length=15)
    email=models.EmailField(max_length=30,primary_key=True)
    password=models.CharField(max_length=30)
