from django import forms
from myapp.models import Category, Expense,User

class CategoryForm(forms.ModelForm):
    class Meta:
        model=Category
        fields='__all__'

class ExpenseForm(forms.ModelForm):
    class Meta:
        model=Expense
        fields='__all__'

class UserForm(forms.ModelForm):
    class Meta:
        model=User
        fields='__all__'