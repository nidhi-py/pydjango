from django.contrib import admin
from django.urls import path
from .import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.Homepage),
    path('Homepage',views.Homepage),
    path('addCategorypage',views.addCategorypage),
    path('addCategory',views.addCategory),
    path('CategoryList',views.CategoryList),
    path('deleteCategory/<str:cname>',views.DeleteCategory),
    path('addExpensepage',views.addExpensepage),
    path('addExpense',views.addExpense),
    path('ExpenseList',views.ExpenseList),
    path('deleteExpense/<int:id>',views.DeleteExpense),
    path('editExpense',views.EditExpense),
    path('UpdateExpense',views.UpdateExpense),
    path('addUserpage',views.addUserpage),
    path('addUser',views.addUser),
    path('Loginpage',views.loginpage),
    path('login',views.login),
    path('logoutpage',views.logout),
]
