from django.shortcuts import render,redirect
from django.http import HttpResponse
from myapp.models import Category,User,Product,Cart
from myapp.form import categoryForm,userForm,productForm
# Create your views here.

def homepage(request):
    c=Category.objects.all()
    cat=request.GET.get('cat')
    if cat is not None:
        pl=Product.objects.filter(cname=cat)
        return render(request,'home.html',{'c':c,'pl':pl})
    else:
        pl=Product.objects.all()
        return render(request,'home.html',{'c':c,'pl':pl})

def addcategorypage(request):
    a= categoryForm
    return render(request,'addcategory.html',{'form':a})

def addcategory(request):
    a= categoryForm(request.POST)
    if a.is_valid:
        a.save()
        return render(request,'home.html')
    return HttpResponse('<h1> FAIL </h1>')

def deleteCategory(request):
    cname=request.GET.get('cname')
    e=Category.objects.get(cname=cname)
    e.delete()
    return render(request,'home.html')

def categorylist(request):
    c= Category.objects.all()
    return render(request, 'categorylist.html',{'form1':c})

def adduserpage(request):
    u= userForm  #it will consider the bracket anyhow
    return render(request,'adduser.html',{'form2':u})

def addUser(request):
    u= userForm(request.POST)
    if u.is_valid:
        u.save()
        return render(request,'home.html')
    return HttpResponse('<h1> Fail </h1>')

def userList(request):
    ul=User.objects.all()
    return render(request,'userlist.html',{'url':ul})

def deleteUser(request,email):
    n=User.objects.get(email=email)
    n.delete()
    return render(request,'home.html')

def EditUser(request):
    email=request.GET.get('email')
    t=User.objects.get(email=email)
    f=userForm(instance=t) #instance=object
    return render(request,'updateuser.html',{'form':f,'email':email}) #{'form':f,'email':email}--because the data will go to update.html page otherwise the form will be empty and no data is printed 
 #instance is used because we don't have update() function

def UpdateUser(request):
    email=request.GET.get('email')
    t=User.objects.get(email=email)
    f=userForm(request.POST,instance=t)
    f.save()
    return redirect('/userlist')

def myTemp(request):
    return render(request,'myTemp.html')


def addproductpage(request):
    p= productForm
    return render(request,'addproduct.html',{'ap':p})

def addProduct(request):
    p=productForm(request.POST)
    if p.is_valid:
        p.save()
        return render(request,'home.html')
    return HttpResponse('<h1> Fail </h1>')

def productList(request):
    pl=Product.objects.all()
    return render(request,'productlist.html',{'prl':pl})

def deleteProduct(request,id):
    s=Product.objects.get(id=id)
    s.delete()
    return render(request,'home.html')

def EditProduct(request):
    id=request.GET.get('id')
    x=Product.objects.get(id=id)
    q=productForm(instance=x) #instance=object
    return render(request,'updateproduct.html',{'form':q,'id':id})

def UpdateProduct(request):
    id=request.GET.get('id')
    x=Product.objects.get(id=id)
    q=productForm(request.POST,instance=x)
    q.save()
    return redirect('/productlist')

def loginpage(request):
    return render(request,'login.html')

def login(request):
    em=request.POST.get('email')
    passwd=request.POST.get('password')
    #print(email,'  ',password)
    if em=="nidhi@123" and passwd=="21298":
        request.session['admin']=em
        return redirect('/homepage')
    else:
        try:
            ul=User.objects.get(email=em)
            if em==ul.email and passwd==ul.password:
                request.session['username']=em
                return redirect("/homepage")
            else:
                return HttpResponse("Template not found")
        except:
            return render(request,'login.html')#{'msg':""}

def Logout(request):
    ls=list(request.session.keys())
    for i in ls:
        del request.session[i]
    return redirect('/homepage')

def MyAccount(request):
    ac=User.objects.all()
    return render(request,'myaccount.html',{'a':ac})

def EditProfile(request):
    email=request.GET.get('email')
    p=User.objects.get(email=email)
    j=userForm(instance=p)
    return render(request,'updateprofile.html',{'email':email,'form':j})

def UpdateProfile(request):
    email=request.GET.get('email')
    p=User.objects.get(email=email)
    j=userForm(request.POST,instance=p)
    j.save()
    return redirect('/homepage')

def AddtoCart(request):
    pid=request.GET.get('pid')
    prod=Product.objects.get(id=pid)
    email=request.session.get('username')
    user=User.objects.get(email=email)
    c=Cart()
    c.email=user
    c.pid=prod
    c.save()
    return redirect("/homepage")

def CartList(request):
    email=request.session.get('username')
    cartlist=Cart.objects.filter(email=email)
    cl=Category.objects.all()
    return render(request,'mycart.html',{'crl':cartlist,'cl':cl})

print(type(type(1)))