from django.db import models

# Create your models here.
class Category(models.Model):
    cname =models.CharField(max_length=30, primary_key=True) #cname=categoryname
    
class User(models.Model):
    name=models.CharField(max_length=30)
    contact=models.CharField(max_length=15)
    email=models.CharField(primary_key=True,max_length=15)
    password=models.CharField(max_length=30)

class Product(models.Model):
    pname=models.CharField(max_length=30)
    price=models.CharField(max_length=15)
    description=models.TextField(max_length=30)
    cname=models.ForeignKey(Category,on_delete=models.CASCADE)

class Cart(models.Model):
    email=models.ForeignKey(User,on_delete=models.CASCADE)
    pid=models.ForeignKey(Product,on_delete=models.CASCADE)
    qty=models.IntegerField(default=1)