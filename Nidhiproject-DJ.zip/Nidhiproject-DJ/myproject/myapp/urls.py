from django.contrib import admin
from django.urls import path
from .import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.homepage),
    path('homepage',views.homepage),
    path('addcategorypage',views.addcategorypage),
    path('addcategory',views.addcategory),
    path('categorylist',views.categorylist),
    path('deleteCategory',views.deleteCategory),
    path('adduserpage',views.adduserpage),
    path('user',views.addUser),
    path('userlist',views.userList),
    path('deleteUser/<str:email>',views.deleteUser),
    path('editUser',views.EditUser),
    path('updateUser',views.UpdateUser),
    path('addproductpage',views.addproductpage),
    path('product',views.addProduct),
    path('productlist',views.productList),
    path('deleteProduct/<int:id>',views.deleteProduct),
    path('editProduct',views.EditProduct),
    path('updateProduct',views.UpdateProduct),
    path('loginpage',views.loginpage),
    path('login',views.login),
    path('logoutpage',views.Logout),
    path('Myaccount',views.MyAccount),
    path('editprofile',views.EditProfile),
    path('updateProfile',views.UpdateProfile),
    path('addtocart',views.AddtoCart), 
    path('cartlist',views.CartList),

]
