from django import forms
from myapp.models import Category,User,Product

class categoryForm(forms.ModelForm):
    class Meta:
        model=Category
        fields='__all__'

class userForm(forms.ModelForm):
    class Meta:
        model=User
        fields='__all__'

class productForm(forms.ModelForm):
    class Meta:
        model=Product
        fields='__all__'